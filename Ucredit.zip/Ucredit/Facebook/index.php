<!DOCTYPE html>
<html>
<head>
	<title>Facebook Graph API using php </title>
</head>
<body>
<center>
	<h1>Facebook Graph API (v3.3) in PHP</h1>
	<a href="login.php">Login with facebook </a>
</center>
</body>
</html>