<?php

session_start();
require 'C:\xampp\htdocs\MyFirst\Facebook\autoload.php';
$fb = new Facebook\Facebook([
  'app_id' => '455456625241520', // Replace {app-id} with your app id
  'app_secret' => '7c0891ffc2bd715844bd195cde71e7d9',
  'default_graph_version' => 'v3.3',
  ]);

$helper = $fb->getRedirectLoginHelper();

$permissions = ['email']; // Optional permissions
$loginUrl = $helper->getLoginUrl('https://MyFirst/Facebook/callback.php', $permissions);

header("loacation:".$loginUrl);

?>